#Smart Glove for Sign-to-Speech Conversion
#Receives gesture labels from Arduino and converts them to speech

import serial
import pyttsx3
import time
import threading

#CHANGE THIS PORT ACCORDING TO YOUR SYSTEM
arduino = serial.Serial("COM3", 9600)

#Allow Arduino to initialize
time.sleep(2)

#Store the previously spoken gesture
last_spoken = ""

#Gestures recognized by the Arduino
valid_words = [
    "HELLO",
    "YES",
    "HELP",
    "THANK YOU",
    "FOOD",
    "WATER",
    "EMERGENCY"
]

print("System Started")


#Speech function
def speak(word):
    engine = pyttsx3.init("sapi5")
    engine.setProperty("rate", 150)

    engine.say(word)
    engine.runAndWait()

    engine.stop()


#Main serial processing loop
while True:
    try:
        #Read data sent by Arduino
        data = arduino.readline().decode().strip()

        print(data)

        #Check whether received data is a valid gesture
        if data in valid_words:
            #Prevent repeatedly speaking the same gesture
            if data != last_spoken:
                print("Speaking:", data)

                #Run speech in a separate thread
                threading.Thread(
                    target=speak,
                    args=(data,)
                ).start()

                last_spoken = data
                time.sleep(0.5)

    except Exception as e:
        print("Error:", e)
