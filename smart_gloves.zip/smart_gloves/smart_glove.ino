//Smart Glove for Sign-to-Speech Conversion
//Arduino Uno + 3 Flex Sensors
//Adaptive Calibration + Rule-Based Gesture Recognition

int indexF;
int middleF;
int ringF;

int indexBase;
int middleBase;
int ringBase;

int indexThreshold;
int middleThreshold;
int ringThreshold;

void setup()
{
  Serial.begin(9600);

  Serial.println("================================");
  Serial.println("ADAPTIVE CALIBRATION STARTING");
  Serial.println("KEEP ALL FINGERS STRAIGHT");
  Serial.println("DO NOT MOVE");
  Serial.println("================================");

  delay(4000);

  //Learn normal sensor values
  indexBase = getAverage(A1);
  middleBase = getAverage(A2);
  ringBase = getAverage(A3);

  //Calculate user-specific thresholds
  indexThreshold = indexBase - 25;
  middleThreshold = middleBase - 18;
  ringThreshold = ringBase - 25;

  Serial.println();
  Serial.println("CALIBRATION COMPLETE");
  Serial.println("SYSTEM READY");
  Serial.println();

  Serial.print("Index Base: ");
  Serial.println(indexBase);

  Serial.print("Middle Base: ");
  Serial.println(middleBase);

  Serial.print("Ring Base: ");
  Serial.println(ringBase);

  Serial.println("================================");

  delay(2000);
}

void loop()
{
  //Read smoothed sensor values
  indexF = getAverage(A1);
  middleF = getAverage(A2);
  ringF = getAverage(A3);

  //Print sensor readings
  Serial.print("I:");
  Serial.print(indexF);
  Serial.print(" M:");
  Serial.print(middleF);
  Serial.print(" R:");
  Serial.println(ringF);

  //Detect whether each finger is bent
  bool indexBent = indexF < indexThreshold;
  bool middleBent = middleF < middleThreshold;
  bool ringBent = ringF < ringThreshold;

  //3 sensors = 7 gestures

  if(indexBent && middleBent && ringBent)
  {
    Serial.println("EMERGENCY");
  }
  else if(indexBent && middleBent)
  {
    Serial.println("THANK YOU");
  }
  else if(indexBent && ringBent)
  {
    Serial.println("FOOD");
  }
  else if(middleBent && ringBent)
  {
    Serial.println("WATER");
  }
  else if(indexBent)
  {
    Serial.println("HELLO");
  }
  else if(middleBent)
  {
    Serial.println("YES");
  }
  else if(ringBent)
  {
    Serial.println("HELP");
  }

  delay(700);
}

//Sensor smoothing function
int getAverage(int pin)
{
  long total = 0;

  //Take 15 readings to reduce noise
  for(int i = 0; i < 15; i++)
  {
    total += analogRead(pin);
    delay(5);
  }

  return total / 15;
}
